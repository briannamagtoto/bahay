# BAHAY

[Video Link](https://youtu.be/RokOR3H8px8)

# Overview

**BAHAY** is an one-page storytelling website that explores the concept of *home*. The website reflects the experience of moving away from home to college at Yale, trying to find a new sense of belonging, and dealing with confusion and homesickness. The name "BAHAY" means "home" in Filipino, and the project is inspired by my personal journey as I navigated the complexities of adjusting to college life while missing my home and trying to find a new sense of "home" in a new place.

# Installation/Setup

1. Clone the repository
2. Navigate to the project folder
3. Open the index.html file on your web browser 

# 
Made by Brianna Magtoto / CS50 Final Project / Yale University
